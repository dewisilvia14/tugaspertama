@extends('layouts.app')

@section('title', 'urutan')



@section ('content')

@foreach ($numbers as $numbers)
<h1> Urutan ke - {{[$number['ke']}}
    <h3>nomor ke - ([$nomor])
@foreach
   
 @endsection 
</body>
</html>