@extends('layouts.app')

@section('title', 'cobaaaa')

@section ('content')
    Urutan ke - ([$ke])

</body>
</html>